
<?php $__env->startSection('content'); ?>
<title>Data Admin | Kasir</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Tambah Data</h6>
    </div>
    <div class="card-body">
        <?php if( Session::get('masuk') !=""): ?>
            <div class='alert alert-success'><center><b><?php echo e(Session::get('masuk')); ?></b></center></div>        
        <?php endif; ?>
        <form action="<?php echo e(url('/error-map/store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Nama</label>
                <input type="text" name="name" class="form-control" value="<?php echo e(Auth::user()->name); ?>" readonly required>
            </div>
            <div class="form-group">
                <label for="work_map_id">Map</label>
                <select name="work_map_id" class="form-control" required>
                        <option value="" disabled selected>Pilih Map</option>
                    <?php $__currentLoopData = $workmap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($m->id); ?>"><?php echo e($m->map->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="date">Tanggal</label>
                <input type="date" name="date" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="image">Gambar</label>
                <input type="file" name="image" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="comments">Komentar</label>
                <textarea name="comments" id="comments" class="form-control" cols="20" rows="5"></textarea>
            </div>
            <input type="submit" value="Masukan Data Error" class="btn btn-primary">
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_laporan\resources\views/error-map/create.blade.php ENDPATH**/ ?>