<table class="table table-bordered"  id="dataTable">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Map</th>
            <th>Status</th>
            <th>Date Adopted</th>
            <th>Date Expired</th>
            <th>Priority</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $in; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($u->name); ?></td>
            <td><?php echo e($u->status); ?></td>
            <td><?php echo e($u->date_adopted); ?></td>
            <td><?php echo e($u->date_expired); ?></td>
            <td><?php echo e($u->priority); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /home/nomen/LARAVEL FILE/laravel_laporan/resources/views/report/in/table.blade.php ENDPATH**/ ?>