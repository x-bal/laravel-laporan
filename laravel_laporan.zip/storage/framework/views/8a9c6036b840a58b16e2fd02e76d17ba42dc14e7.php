
<?php $__env->startSection('content'); ?>
<title>Data User | Kasir</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Data Error</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <?php if( Session::get('masuk') !=""): ?>
            <div class='alert alert-success'><center><b><?php echo e(Session::get('masuk')); ?></b></center></div>        
            <?php endif; ?>
            <?php if( Session::get('update') !=""): ?>
            <div class='alert alert-success'><center><b><?php echo e(Session::get('update')); ?></b></center></div>        
            <?php endif; ?>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong style="color:red"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Map</th>
                        <th>Tanggal</th>
                        <th>Gambar</th>
                        <th>Komentar</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $error; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$i); ?></td>
                        <td><?php echo e($u->workMap->user->name); ?></td>
                        <td><?php echo e($u->workMap->map->name); ?></td>
                        <td><?php echo e($u->date); ?></td>
                        <td><a href="<?php echo e(asset('image/'.$u->image)); ?>" target="_blank">Lihat Gambar</a></td>
                        <td><?php echo e($u->comments); ?></td>
                        <td>
                            <a href="<?php echo e(url('/error-map/edit/'.$u->id)); ?>" class="btn btn-primary btn-sm ml-2">Edit</a>
                            <a href="<?php echo e(url('/error-map/delete/'.$u->id)); ?>" class="btn btn-danger btn-sm ml-2" onclick="return confirm('Apakah Anda Yakin ?')">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\laravel_laporan\resources\views/error-map/index.blade.php ENDPATH**/ ?>