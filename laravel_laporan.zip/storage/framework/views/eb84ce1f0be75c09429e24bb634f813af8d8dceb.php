
<?php $__env->startSection('content'); ?>
<title>Data Admin | Kasir</title>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php if(auth()->user()->level != 'U'): ?>
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Laporan Cuti Tahunan</h6>
                </div>
                <div class="card-body">
                    <?php if( Session::get('masuk') !=""): ?>
                    <div class='alert alert-success'>
                        <center><b><?php echo e(Session::get('masuk')); ?></b></center>
                    </div>
                    <?php endif; ?>

                    <form action="" method="get" class="mb-3">
                        <div class="row">
                            <div class="col">
                                <select name="tahun" id="tahun" class="form-control">
                                    <option disabled selected>-- Pilih Tahun --</option>
                                    <option <?php echo e(request('tahun') == '2021' ? 'selected' : ''); ?> value="2021">2021</option>
                                    <option <?php echo e(request('tahun') == '2022' ? 'selected' : ''); ?> value="2022">2022</option>
                                    <option <?php echo e(request('tahun') == '2023' ? 'selected' : ''); ?> value="2023">2023</option>
                                </select>
                            </div>
                            <div class="col">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_laporan\resources\views/report/cuti/preview.blade.php ENDPATH**/ ?>