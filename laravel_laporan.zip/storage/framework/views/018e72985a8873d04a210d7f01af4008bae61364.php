
<?php $__env->startSection('content'); ?>
<title>Data Admin | Kasir</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Edit Data</h6>
    </div>
    <div class="card-body">
        <?php if( Session::get('masuk') !=""): ?>
            <div class='alert alert-success'><center><b><?php echo e(Session::get('masuk')); ?></b></center></div>        
        <?php endif; ?>
        <form action="<?php echo e(url('/error-map/update')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Nama</label>
                <input type="hidden" name="id" value="<?php echo e($error->id); ?>">
                <input type="text" name="name" class="form-control" readonly value="<?php echo e($error->workMap->user->name); ?>" readonly required>
            </div>
            <div class="form-group">
                <label for="work_map_id">Map</label>
                <input type="text" name="map" class="form-control" readonly value="<?php echo e($error->workMap->map->name); ?>" required>
            </div>
            <div class="form-group">
                <label for="date">Tanggal</label>
                <input type="date" name="date" class="form-control" readonly required>
            </div>
            <div class="form-group">
                <label for="image">Gambar</label>
                <br>
                <img src="<?php echo e(url('image/'.$error->image)); ?>" alt="" class="w-50">
            </div>
            <div class="form-group">
                <label for="comments">Komentar</label>
                <textarea name="comments" id="comments" class="form-control" cols="20" rows="5"><?php echo e($error->comments); ?></textarea>
            </div>
            <input type="submit" value="Update" class="btn btn-success">
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_laporan\resources\views/error-map/edit.blade.php ENDPATH**/ ?>