
<?php $__env->startSection('content'); ?>
<?php if(auth()->user()->level == 'A'): ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Laporan</h6>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <a href="<?php echo e(url('report/in')); ?>" class="btn btn-primary form-control">Map Masuk</a>
                <a href="<?php echo e(url('report/finish')); ?>" class="btn btn-primary form-control mt-2">Map Selesai</a>
                <a href="<?php echo e(url('report/error')); ?>" class="btn btn-primary form-control mt-2">Map Error</a>
            </div>
            <div class="col-md-6">
                <a href="<?php echo e(url('report/progress')); ?>" class="btn btn-primary form-control">Map Progress</a>
                <a href="<?php echo e(url('report/total')); ?>" class="btn btn-primary form-control mt-2">Total Map Karyawan</a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Laporan Karyawan</h6>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <a href="<?php echo e(url('report/akumulasi')); ?>" class="btn btn-primary form-control mt-2">Laporan Akumulasi</a>
                <a href="<?php echo e(url('report/cuti')); ?>" class="btn btn-primary form-control mt-2">Laporan Cuti Tahunan</a>
            </div>
            <div class="col-md-6">
                <a href="<?php echo e(route('gaji.laporan')); ?>" class="btn btn-primary form-control mt-2">Laporan Gaji Karyawan</a>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_laporan\resources\views/report/index.blade.php ENDPATH**/ ?>