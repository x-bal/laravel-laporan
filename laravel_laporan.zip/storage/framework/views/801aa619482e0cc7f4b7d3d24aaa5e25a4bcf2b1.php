<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Akumulasi Gaji Bulanan</title>
</head>

<body>
    <header style="border-bottom: 3px solid black; justify-content: center;">
        <div class="logo">
            <img src="https://i.postimg.cc/GpJD05R7/logo-pen.png" alt="" width="100px" style="margin-left: 50px;">
        </div>
        <p style="text-align: center; margin-top: -100px;">
            <b style="font-size: 14px;">CV. PENINSULA ABADI</b><br>
        </p>
        <p style="text-align: center; font-size: 11px;">
            Jl. H Anang Adenansi No 4 RT 01 RW 001, Kel. Teluk Dalam, Kec. Banjarmasin Tengah,<br> Kota Banjarmasin, Prov. Kalimantan Selatan. <br>
            Telp. (085) 696338649 Fax. (025) 1231212312 <br>
            Email : peninsula.abadi@gmail.com.
        </p>
    </header>

    <div class="content" style="margin: auto; width: 70%; display: block; justify-content: center; border-bottom: 1px solid black;">
        <h4 style="text-transform: uppercase;">TOTAL PENGELUARAN BIAYA KARYAWAN PADA TAHUN <?php echo e($tahun); ?></h4>
        <div class=" gaji" style="margin-top: 20px;">
            <p>
                GAJI KARYAWAN
            </p>
            <table style="font-size: 12px;" border="1" cellspacing="0">
                <tr>
                    <td width="20px" style="text-align: center;">No.</td>
                    <td width="320px">Nama Karyawan</td>
                    <td width="150px" style="text-align: center;">Gaji</td>
                </tr>
                <?php $__currentLoopData = $akumulasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td width="20px" style="text-align: center;"><?php echo e($loop->iteration); ?></td>
                    <td width="200px"><?php echo e($akm->karyawan->nama); ?></td>
                    <td width="180px" style="text-align: center;">Rp. <?php echo e($akm->gaji->gaji); ?></td>
                </tr>
                <?php
                $gaji = 0;
                $gaji += $akm->gaji->gaji
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <table style="font-size: 12px; margin-top: 20px; margin-bottom: 20px;" cellspacing="0">
                <tr>
                    <td>
                        Total Gaji
                    </td>
                    <td width="330px"> : </td>
                    <td width="150px" style="text-align: center;">Rp. <?php echo e($gaji); ?></td>
                </tr>
            </table>
        </div>

        <div class="tambahan" style="margin-top: 20px;">
            <p>
                PENDAPATAN KARYAWAN
            </p>
            <table style="font-size: 12px;" border="1" cellspacing="0">
                <tr>
                    <td width="20px" style="text-align: center;">No.</td>
                    <td width="300px">Nama Karyawan</td>
                    <td width="50px" style="text-align: center;">Bonus</td>
                    <td width="150px" style="text-align: center;">Rp.</td>
                </tr>
                <?php $__currentLoopData = $pendapatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pnd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td width="20px" style="text-align: center;"><?php echo e($loop->iteration); ?></td>
                    <td width="200px"><?php echo e($pnd->user->karyawan->nama); ?></td>
                    <td style="text-align: center;"><?php echo e($pnd->jenis->name); ?></td>
                    <td width="100px" style="text-align: center;">Rp. <?php echo e($pnd->jenis->nominal); ?></td>
                </tr>
                <?php
                $totalPend += $pnd->jenis->nominal

                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <table style="font-size: 12px; margin-top: 20px; margin-bottom: 20px;" cellspacing="0">
                <tr>
                    <td>
                        Total Pendapatan Karyawan
                    </td>
                    <td width="250px"> : </td>
                    <td width="150px" style="text-align: center;">Rp. <?php echo e($totalPend); ?></td>
                </tr>
            </table>
        </div>

        <div class="pengurangan" style="margin-top: 20px; margin-bottom: 10px;">
            <p>
                PENGURANGAN KARYAWAN
            </p>
            <table style="font-size: 12px;" border="1" cellspacing="0">
                <tr>
                    <td width="20px" style="text-align: center;">No.</td>
                    <td width="300px">Nama Karyawan</td>
                    <td width="50px" style="text-align: center;">Alasan</td>
                    <td width="150px" style="text-align: center;">Rp.</td>
                </tr>
                <?php $__currentLoopData = $pengurangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peng): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td width="20px" style="text-align: center;"><?php echo e($loop->iteration); ?></td>
                    <td width="200px"><?php echo e($peng->user->karyawan->nama); ?></td>
                    <td style="text-align: center;"><?php echo e($peng->jenis->name); ?></td>
                    <td width="100px" style="text-align: center;">Rp. <?php echo e($peng->jenis->nominal); ?></td>
                </tr>
                <?php
                $totalPeng += $peng->jenis->nominal

                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <table style="font-size: 12px; margin-top: 20px; margin-bottom: 20px;" cellspacing="0">
                <tr>
                    <td>
                        Total Pengurangan
                    </td>
                    <td width="290px"> : </td>
                    <td width="150px" style="text-align: center;">Rp. <?php echo e($totalPeng); ?></td>
                </tr>
            </table>
            <table style="font-size: 12px; margin-top: 20px; margin-bottom: 20px;" cellspacing="0">
                <?php
                $totalKaryawan = \App\User::with('karyawan')->where('level', '!=', 'A')->count()
                ?>
                <tr>
                    <td>
                        BPJS
                    </td>
                    <td width="360px"> : </td>
                    <td width="150px" style="text-align: center;">Rp. <?php echo e(($bpjs->nominal * 12) * $totalKaryawan); ?></td>
                </tr>
            </table>
        </div>
    </div>

    <div class="total" style="margin: auto; width: 70%; display: block; justify-content: center; border-bottom: 1px solid black;">
        <table style="font-size: 12px; margin-top: 20px; margin-bottom: 20px;" cellspacing="0">
            <tr>
                <td style="text-align: center;">
                    Total Pengeluaran
                </td>
                <td width="300px"> : </td>
                <td width="150px" style="text-align: center;">Rp. <?php echo e(($gaji + $totalPend) - ($totalPeng + $bpjs->nominal)); ?></td>
            </tr>
        </table>
    </div>

    <div class="footer" style="text-align: end; margin-top: 50px;">
        <table style="margin-left: 120px;">
            <tr style="text-align: center;">
                <td><b>BENDAHARA</b><br><br><br><br></td>
                <td width="300px"></td>
                <td><b>DIREKTUR</b><br><br><br><br></td>
            </tr>
            <tr style="text-align: center;">
                <td>
                    <b>Iin Ardalina</b>
                </td>
                <td width="300px"></td>
                <td>
                    <b>Azhar Arif, RF S. AB</b>
                </td>
            </tr>
        </table>
    </div>


    <script>
        window.load(print())
    </script>
</body>

</html><?php /**PATH D:\xampp\htdocs\laravel_laporan\resources\views/report/gaji/akumulasi-tahunan.blade.php ENDPATH**/ ?>