
<?php $__env->startSection('content'); ?>
<title>Data Admin | Kasir</title>
<div class="row">
    <div class="col-md-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Slip Gaji Karyawan</h6>
            </div>
            <div class="card-body">
                <?php if( Session::get('masuk') !=""): ?>
                <div class='alert alert-success'>
                    <center><b><?php echo e(Session::get('masuk')); ?></b></center>
                </div>
                <?php endif; ?>

                <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('gaji.laporanKaryawan', $month->tanggal)); ?>" class="btn btn-primary"><?php echo e($month->tanggal); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_laporan\resources\views/gaji/slip.blade.php ENDPATH**/ ?>