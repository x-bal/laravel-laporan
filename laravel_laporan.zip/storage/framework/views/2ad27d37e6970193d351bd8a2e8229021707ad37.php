
<?php $__env->startSection('content'); ?>
<title>Data Gaji Karyawan | Kasir</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Data Gaji Karyawan</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <?php if( Session::get('masuk') !=""): ?>
            <div class='alert alert-success'>
                <center><b><?php echo e(Session::get('masuk')); ?></b></center>
            </div>
            <?php endif; ?>
            <?php if( Session::get('update') !=""): ?>
            <div class='alert alert-success'>
                <center><b><?php echo e(Session::get('update')); ?></b></center>
            </div>
            <?php endif; ?>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong style="color:red"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <form action="" method="get" class="mb-3">
                <div class="row">
                    <div class="col">
                        <select name="divisi" id="divisi" class="form-control">
                            <option disabled selected>-- Pilih Divisi --</option>
                            <option <?php echo e(request('divisi') == 'all' ? 'selected' : ''); ?> value="all">All</option>
                            <option <?php echo e(request('divisi') == 'Mapping' ? 'selected' : ''); ?> value="Mapping">Mapping</option>
                            <option <?php echo e(request('divisi') == 'Property Marketing' ? 'selected' : ''); ?> value="Property Marketing">Property Marketing</option>
                        </select>
                    </div>
                    <div class="col">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-print"></i></button>
                    </div>
                </div>
            </form>
            <button type="button" class="btn btn-primary mb-3" data-toggle="modal" data-target="#tambah">Tambah</button>

            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>No Hp</th>
                        <th>Divisi</th>
                        <th>Tgl Masuk</th>
                        <th>Tgl Bayar</th>
                        <th>Nominal</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <?php $__currentLoopData = $gaji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($gj->user->karyawan->nama); ?></td>
                        <td><?php echo e($gj->user->karyawan->nohp); ?></td>
                        <td><?php echo e($gj->user->karyawan->divisi); ?></td>
                        <td><?php echo e($gj->tgl_masuk); ?></td>
                        <td><?php echo e($gj->tgl_bayar); ?></td>
                        <td><?php echo e($gj->gaji); ?></td>
                        <td class="text-center">
                            <a href="" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit<?php echo e($gj->id); ?>"><i class="fas fa-edit"></i></a>
                            <form action="<?php echo e(route('gaji.destroy', $gj->id)); ?>" method="post" style="display: inline;" onclick="return confirm('Hapus data?')">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>

                    <div id="edit<?php echo e($gj->id); ?>" class="modal fade" tabindex="-1" role="dialog">
                        <div class="modal-dialog" role="document">
                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">Update Data</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(route('gaji.update', $gj->id)); ?>" method="post">
                                        <?php echo method_field('PATCH'); ?>
                                        <?php echo csrf_field(); ?>

                                        <div class="form-group">
                                            <label for="nohp">No Hp</label>
                                            <input type="number" name="nohp" class="form-control" value="<?php echo e($gj->nohp); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="tgl_masuk">Tanggal Masuk</label>
                                            <input type="date" name="tgl_masuk" class="form-control" required value="<?php echo e($gj->tgl_masuk); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="tgl_bayar">Tanggal Pembayaran</label>
                                            <input type="number" name="tgl_bayar" class="form-control" required value="<?php echo e($gj->tgl_bayar); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="gaji">Nominal Gaji</label>
                                            <input type="number" name="gaji" class="form-control" required value="<?php echo e($gj->gaji); ?>">
                                        </div>

                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Update</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="tambah" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Masukan Data</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('gaji.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="nama">Nama</label>
                        <select name="user" id="user" class="form-control">
                            <option disabled selected>-- Pilih Karyawan --</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->karyawan->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="tgl_masuk">Tanggal Masuk</label>
                        <input type="date" name="tgl_masuk" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="tgl_bayar">Tanggal Pembayaran</label>
                        <input type="number" name="tgl_bayar" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="gaji">Nominal Gaji</label>
                        <input type="number" name="gaji" class="form-control" required>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Tambah</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_laporan\resources\views/gaji/index.blade.php ENDPATH**/ ?>