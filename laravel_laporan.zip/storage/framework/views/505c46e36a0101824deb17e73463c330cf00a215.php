
<?php $__env->startSection('content'); ?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-dark">Masukan Tanggal</h6>
    </div>
    <div class="card-body">
        <form action="<?php echo e(url('report/in/store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="">Tanggal Map Masuk</label>
                        <input type="date" name="req1" class="form-control" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="">Hingga Tanggal</label>
                        <input type="date" name="req2" class="form-control" required>
                    </div>
                </div>
            </div>
            <center><input type="submit" class="btn btn-success"></center>
      </form>
<br>
    </div>
</div>
<div class="card shadow mb-4">
<div class="card-header py-3">
  <h6 class="m-0 font-weight-bold text-dark">Laporan Map Masuk</h6>
</div>
<div class="card-body">
  <div class="table-responsive">
     <?php if($hitung == 0): ?>
        
    <?php else: ?>
    
    <form action="<?php echo e(url('report/in/export')); ?>" method="POST">
    <?php echo csrf_field(); ?>
        <input type="hidden" name="req1" value="<?php echo e($req1); ?>">
        <input type="hidden" name="req2" value="<?php echo e($req2); ?>">
       <input type="submit" class="btn btn-warning" value="EXPORT EXCEL">
       
       </form>
    <?php endif; ?>
       <br>
    <?php echo $__env->make('report.in.table', $in, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
</div>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nomen/LARAVEL FILE/laravel_laporan/resources/views/report/in/index.blade.php ENDPATH**/ ?>