<table class="table table-bordered"  id="dataTable">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Map</th>

        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $workMap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($u->user->name); ?></td>
            <td><?php echo e($u->map->name); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH E:\Laravel\laravel_laporan\resources\views/report/total/table.blade.php ENDPATH**/ ?>