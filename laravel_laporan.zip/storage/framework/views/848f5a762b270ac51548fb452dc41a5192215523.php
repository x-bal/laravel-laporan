<table class="table table-bordered"  id="dataTable">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Map</th>
            <th>Tanggal</th>
            <th>Gambar</th>
            <th>Komentar</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $error; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($u->workMap->user->name); ?></td>
            <td><?php echo e($u->workMap->map->name); ?></td>
            <td><?php echo e($u->date); ?></td>
            <td><?php echo e($u->image); ?></td>
            <td><?php echo e($u->comments); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\xampp\htdocs\laravel_laporan\resources\views/report/error/table.blade.php ENDPATH**/ ?>