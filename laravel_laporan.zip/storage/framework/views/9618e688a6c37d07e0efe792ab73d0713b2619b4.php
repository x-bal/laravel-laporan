
<?php $__env->startSection('content'); ?>
<title>Data Admin | Kasir</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Edit Data</h6>
    </div>
    <div class="card-body">
        <form action="<?php echo e(url('/admin/update')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="">Nama Admin</label>
                <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                <input type="text" name="name" class="form-control" value="<?php echo e($user->karyawan->nama); ?>">
            </div>
            <div class="form-group">
                <label for="">Email</label>
                <input type="text" name="email" class="form-control" value="<?php echo e($user->email); ?>">
            </div>
            <div class="form-group">
                <label for="">Jenis Kelamin</label>
                <select name="jk" id="jk" class="form-control">
                    <?php if($user->karyawan->jk== 'P'): ?>
                    <option value="P" selected>Perempuan</option>
                    <option value="L">Laki - laki</option>
                    <?php else: ?>
                    <option value="P">Perempuan</option>
                    <option value="L" selected>Laki - laki</option>
                    <?php endif; ?>
                </select>
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong style="color:red"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="submit" value="Update" class="btn btn-warning">
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_laporan\resources\views/admin/edit.blade.php ENDPATH**/ ?>