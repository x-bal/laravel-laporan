<table class="table table-bordered"  id="dataTable">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Map</th>
            <th>StartOn</th>
            <th>Progress</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $workMap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($u->user->name); ?></td>
            <td><?php echo e($u->map->name); ?></td>
            <td><?php echo e($u->start_on); ?></td>
            <td><?php echo e($u->progress); ?> %</td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\xampp\htdocs\laravel_laporan\resources\views/report/progress/table.blade.php ENDPATH**/ ?>