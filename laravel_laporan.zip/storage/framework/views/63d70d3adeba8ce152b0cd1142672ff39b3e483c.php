
<?php $__env->startSection('content'); ?>
<title>Data Kehadiran | Kasir</title>
<?php if( Session::get('masuk') !=""): ?>
<div class='alert alert-success'>
    <center><b><?php echo e(Session::get('masuk')); ?></b></center>
</div>
<?php endif; ?>
<?php if( Session::get('update') !=""): ?>
<div class='alert alert-success'>
    <center><b><?php echo e(Session::get('update')); ?></b></center>
</div>
<?php endif; ?>
<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<strong style="color:red"><?php echo e($message); ?></strong>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Data Konfirmasi <?php echo e($jenis->name); ?></h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <?php if($kehadiran != null): ?>
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                    <tr>
                        <?php if(request('jenis') == 1): ?>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th>Status</th>
                        <th class="text-center">Konfirmasi</th>
                        <?php else: ?>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Dari</th>
                        <th>Sampai</th>
                        <th>Keterangan</th>
                        <th>Status</th>
                        <th class="text-center">Konfirmasi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kehadiran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hadir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php if(request('jenis') == 1): ?>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($hadir->user->karyawan->nama); ?></td>
                        <td><?php echo e($hadir->tanggal); ?></td>
                        <td><?php echo e($hadir->keterangan); ?></td>
                        <td><?php echo e($hadir->status); ?></td>
                        <?php else: ?>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($hadir->user->karyawan->nama); ?></td>
                        <td><?php echo e($hadir->dari); ?></td>
                        <td><?php echo e($hadir->sampai); ?></td>
                        <td><?php echo e($hadir->keterangan); ?></td>
                        <td><?php echo e($hadir->status); ?></td>
                        <?php endif; ?>
                        <td class="text-center">
                            <?php if(request('jenis') == 4): ?>
                            <a href="<?php echo e(route('kehadiran.show', $rjc->id)); ?>" class="btn btn-info btn-sm"><i class="fas fa-file"></i></a>
                            <?php endif; ?>
                            <a href="<?php echo e(route('accept', $hadir->id)); ?>" class="btn btn-success btn-sm" onclick="return confirm('Setujui ?')"><i class="fas fa-check"></i></a>
                            <a href="<?php echo e(route('reject', $hadir->id)); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tolak ?')"><i class="fas fa-times"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Data <?php echo e($jenis->name); ?> Disetujui</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <?php if($kehadiran != null): ?>
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                    <tr>
                        <?php if(request('jenis') == 1): ?>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th>Status</th>
                        <th class="text-center">Aksi</th>
                        <?php else: ?>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Dari</th>
                        <th>Sampai</th>
                        <th>Keterangan</th>
                        <th>Status</th>
                        <th class="text-center">Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $accept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php if(request('jenis') == 1): ?>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($acc->user->karyawan->nama); ?></td>
                        <td><?php echo e($acc->tanggal); ?></td>
                        <td><?php echo e($acc->keterangan); ?></td>
                        <td><?php echo e($acc->status); ?></td>
                        <?php else: ?>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($acc->user->karyawan->nama); ?></td>
                        <td><?php echo e($acc->dari); ?></td>
                        <td><?php echo e($acc->sampai); ?></td>
                        <td><?php echo e($acc->keterangan); ?></td>
                        <td><?php echo e($acc->status); ?></td>
                        <?php endif; ?>
                        <td class="text-center">
                            <?php if(request('jenis') == 4): ?>
                            <a href="<?php echo e(route('kehadiran.show', $acc->id)); ?>" class="btn btn-info btn-sm"><i class="fas fa-file"></i></a>
                            <?php endif; ?>
                            <a href="<?php echo e(route('reject', $acc->id)); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tolak ?')"><i class="fas fa-times"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Data <?php echo e($jenis->name); ?> Ditolak</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <?php if($kehadiran != null): ?>
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                    <tr>
                        <?php if(request('jenis') == 1): ?>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th>Status</th>
                        <th class="text-center">Aksi</th>
                        <?php else: ?>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Dari</th>
                        <th>Sampai</th>
                        <th>Keterangan</th>
                        <th>Status</th>
                        <th class="text-center">Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $reject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php if(request('jenis') == 1): ?>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($rjc->user->karyawan->nama); ?></td>
                        <td><?php echo e($rjc->tanggal); ?></td>
                        <td><?php echo e($rjc->keterangan); ?></td>
                        <td><?php echo e($rjc->status); ?></td>
                        <?php else: ?>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($rjc->user->karyawan->nama); ?></td>
                        <td><?php echo e($rjc->dari); ?></td>
                        <td><?php echo e($rjc->sampai); ?></td>
                        <td><?php echo e($rjc->keterangan); ?></td>
                        <td><?php echo e($rjc->status); ?></td>
                        <?php endif; ?>
                        <td class="text-center">
                            <?php if(request('jenis') == 4): ?>
                            <a href="<?php echo e(route('kehadiran.show', $rjc->id)); ?>" class="btn btn-info btn-sm"><i class="fas fa-file"></i></a>
                            <?php endif; ?>
                            <a href="<?php echo e(route('accept', $rjc->id)); ?>" class="btn btn-success btn-sm" onclick="return confirm('Setujui ?')"><i class="fas fa-check"></i></a>
                            <form action="<?php echo e(route('kehadiran.destroy', $rjc->id)); ?>" method="post" style="display: inline;">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda Yakin ?')"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<div id="tambah" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Masukan Data</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('kehadiran.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="user">Pilih User</label>
                        <select name="user" class="form-control" required>
                            <option disabled selected>-- Pilih User --</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->karyawan->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="jenis">Pilih Izin</label>
                        <select name="jenis" class="form-control" required>
                            <option disabled selected>-- Pilih Izin --</option>
                            <?php $__currentLoopData = $jeniss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jns): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jns->id); ?>"><?php echo e($jns->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="dari">Dari</label>
                        <input type="date" name="dari" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="sampai">Sampai</label>
                        <input type="date" name="sampai" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="keterangan">Keterangan</label>
                        <textarea name="keterangan" id="keterangan" rows="3" class="form-control"></textarea>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Tambah</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_laporan\resources\views/kehadiran/index.blade.php ENDPATH**/ ?>