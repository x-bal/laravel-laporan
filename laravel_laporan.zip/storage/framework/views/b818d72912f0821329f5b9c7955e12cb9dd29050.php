
<?php $__env->startSection('content'); ?>
<title>Data Admin | Kasir</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Data Map</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <?php if( Session::get('masuk') !=""): ?>
            <div class='alert alert-success'><center><b><?php echo e(Session::get('masuk')); ?></b></center></div>        
            <?php endif; ?>
            <?php if( Session::get('update') !=""): ?>
            <div class='alert alert-success'><center><b><?php echo e(Session::get('update')); ?></b></center></div>        
            <?php endif; ?>
            <?php if( Session::get('gagal') !=""): ?>
            <div class='alert alert-danger'><center><b><?php echo e(Session::get('gagal')); ?></b></center></div>        
            <?php endif; ?>
            <br>
            <button class="btn btn-success" data-toggle="modal" data-target="#tambah">Tambah Data</button>
            <br>
            <br>
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Status</th>
                        <th>Date Added</th>
                        <th>Date Adopted</th>
                        <th>Date Expired</th>
                        <th>Priority</th>
                        <th>Karyawan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $map; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$i); ?></td>
                        <td><?php echo e($u->name); ?></td>
                        <td><?php echo e($u->status); ?></td>
                        <td><?php echo e(date('Y-m-d',strtotime($u->created_at))); ?></td>
                        <td><?php echo e($u->date_adopted); ?></td>
                        <td><?php echo e($u->date_expired); ?></td>
                        <td><?php echo e($u->priority); ?></td>
                        <td><?php echo e($u->user->name ?? ''); ?></td>
                        <td>
                            <a href="<?php echo e(url('/map/edit/'.$u->id)); ?>" class="btn btn-primary btn-sm ml-2">Edit</a>
                            <a href="<?php echo e(url('/map/delete/'.$u->id)); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda Yakin ?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="tambah" class="modal fade" tabindex="-1" role="dialog">
<div class="modal-dialog" role="document">
    <!-- Modal content-->
    <div class="modal-content">
    <div class="modal-header">
        <h4 class="modal-title">Masukan Data</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-body">
    <form action="<?php echo e(url('/map/store')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="name">Nama</label>
            <input type="text" name="name" class="form-control"  required>
        </div>
        <div class="form-group">
            <label for="status">Status</label>
            <select name="status" class="form-control" required>
                <option value="" disabled selected>Pilih Status</option>
                <option value="adopted">Adopted</option>
                <option value="draft">Draft</option>
            </select>
        </div>
        <div class="form-group">
            <label for="date_adopted">Date Adopted</label>
            <input type="date" name="date_adopted" class="form-control"  required>
        </div>
        <div class="form-group">
            <label for="date_expired">Date Expired</label>
            <input type="date" name="date_expired" class="form-control"  required>
        </div>
        <div class="form-group">
            <label for="priority">Priority</label>
            <select name="priority" class="form-control" required>
                <option value="" disabled selected>Pilih Priority</option>
                <option value="yes">Yes</option>
                <option value="no">No</option>
            </select>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
    </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nomen/LARAVEL FILE/laravel_laporan/resources/views/map/index.blade.php ENDPATH**/ ?>