
<?php $__env->startSection('content'); ?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-dark">Laporan Map Total Pengerjaan Karyawan</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <a href="<?php echo e(url('report/total/export')); ?>" class="btn btn-warning mb-4">Export Excel</a>
            <?php echo $__env->make('report.total.table', $workMap, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\laravel_laporan\resources\views/report/total/index.blade.php ENDPATH**/ ?>